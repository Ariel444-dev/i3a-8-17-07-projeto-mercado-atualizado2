function Home() {

    return (
  
      <div>
  
        <h1>Bem-vindo ao site do MercadoA+</h1>
  
        <p style={style}>Aqui na página inicial estão as informações centrais e mais relevantes sobre nosso sistema de mercados.</p>

        
  
      </div>
  
    );
  
  }
  
  const style = {
      textAlign: 'center',
      border: '0.4px solid blue'
  };

  export default Home;