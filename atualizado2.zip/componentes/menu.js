import "../app/css/menu.css";

function Menu() {

    return (

        <nav>

            <div>
               <h1>Master Mercado</h1>
            </div>

            <div>
                <a href="/">Home</a>&nbsp;

                <a href="/clientes">Clientes</a>&nbsp;

                <a href="/entregas">Entregas</a>&nbsp;

                <a href="/funcionarios">Funcionários</a>&nbsp;

                <a href="/vendas">Vendas</a>

                <a href="/categorias">Vendas</a>
                
                <a href="/produtos">Vendas</a>

            </div>

        </nav>

    );
}



export default Menu;